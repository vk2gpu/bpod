import os
import sys

def error_app(environ, start_response, err='bpod'):
    data = err.encode('ascii')
    start_response('200 OK', [('Content-Type','text/html'), ('Content-Length',str(len(data)))])
    return [data]

def bpod_empty_app(environ, start_response):
    text = '''<html>
<head>
</head>
<body>
<img src="/static/bpod-evil-serial.jpg" />
</body>
</html>'''
    data = text.encode('ascii')
    start_response('200 OK', [('Content-Type','text/html'), ('Content-Length',str(len(data)))])
    return [data]

def application(environ, start_response):
    err = ''
    try:
        return bpod_empty_app(environ, start_response)
    except Exception as error:
        pass
    return error_app(environ, start_response, err)
